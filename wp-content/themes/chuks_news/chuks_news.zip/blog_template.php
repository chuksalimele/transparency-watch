<?php

/*
Template Name: Blog Template
Template Post Type: post, page
*/
?>

<?php get_header(); ?>


<?php get_template_part('template-parts/content', 'blog'); ?>


<?php get_footer(); ?>


