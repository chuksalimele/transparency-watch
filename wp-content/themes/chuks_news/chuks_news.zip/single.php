
<?php get_header(); ?>


<?php get_template_part('template-parts/content', 'single'); ?>


<?php get_footer(); ?>