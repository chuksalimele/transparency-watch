
<section id="content">
    <div class="container">
        <div class="row">

            <?php get_template_part('template-parts/content', 'sidebar'); ?>

            <div class="span8">
                
                <?php the_content(); //for use with Elementor page builder ?>

            </div>



        </div>
    </div>
</section>

