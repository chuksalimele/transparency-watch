

<?php get_template_part('template-parts/head') ?>

    <body>

        <div id="wrapper">

            <?php get_template_part('template-parts/header') ?>
