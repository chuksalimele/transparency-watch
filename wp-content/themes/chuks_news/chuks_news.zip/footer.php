
        <?php get_sidebar('footer'); ?>

        </div>
        <a href="#" class="scrollup"><i class="icon-angle-up icon-square icon-bglight icon-2x active"></i></a>

        <?php wp_footer(); ?>

    </body>
</html>

