
<?php get_header(); ?>


    <section id="inner-headline">
      <div class="container">
        <div class="row">
          <div class="span12">
            <div class="inner-heading">
              <ul class="breadcrumb">
                <li><a href="">Home</a> <i class="icon-angle-right"></i></li>
                <!--<li><a href="#">Pages</a> <i class="icon-angle-right"></i></li>-->
                <li class="active">404</li>
              </ul>
              <h2>404</h2>
            </div>
          </div>
        </div>
      </div>
    </section>

    <section id="content">
      <div class="container">



        <div class="row">
          <div class="span12">
            <div class="aligncenter">
              <i class="icon-circled icon-bgwarning icon-remove icon-4x"></i>
            </div>
            <div class="blankline30"></div>
            <h3 class="aligncenter">Oop!!! Sorry page not found!</h3>
            <!--<p class="aligncenter">Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam non mod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua.-->
            </p>
          </div>

        </div>



      </div>
    </section>



<?php get_footer(); ?>

